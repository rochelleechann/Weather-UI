import { HourlyData } from './hourly-data';

export class HourlyWeather {
    summary: string;
    icon: string;
    data: HourlyData[]
}