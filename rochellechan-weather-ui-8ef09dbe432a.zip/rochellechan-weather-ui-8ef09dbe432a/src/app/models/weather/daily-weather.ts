import { Daily } from './daily';

export class DailyWeather {
    data: Daily[];
}